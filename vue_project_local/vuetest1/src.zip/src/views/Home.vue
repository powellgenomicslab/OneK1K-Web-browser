<template>
  <body>


  <!-- ##############################Homepage content####################################### -->
  <div class="fixed-width l-pad">
    <!-- class="clearfix l-pad l-content-constrained"
     --><section >
    <article>
      <header class="clearfix">
        <h2>About OneK1K</h2>
      </header>

      <p class="homepage-p">Lorem ipsum dolor sit amet, eam ne commodo habemus invenire. Quo ne feugiat platonem, elitr labore in vim. Meis deleniti cu ius, his in suscipit urbanitas torquatos. Soleat ridens euripidis ne cum.>Lorem ipsum dolor sit amet, eam ne commodo habemus invenire. Quo ne feugiat platonem, elitr labore in vim. Meis deleniti cu ius, his in suscipit urbanitas torquatos. Soleat ridens euripidis ne cum.>Lorem ipsum dolor sit amet, eam ne commodo habemus invenire. Quo ne feugiat platonem, elitr labore in vim. Meis deleniti cu ius, his in suscipit urbanitas torquatos. Soleat ridens euripidis ne cum.</p>

    </article>

  </section>
  </div>
  <!-- ##############################Homepage content####################################### -->


  <!-- ##############################Association table####################################### -->


  <!--  <div class=" container clearfix l-pad l-content-constrained">
   -->



  <!-- ##############################Footer####################################### -->
  <footer class="footer">
    <div class="footer-content clearfix">
      <small class="copyright">All Content Copyright 2020-GWCCG. All Rights Researved</small>
      <small class="credits">Site Designed by GWCCG</small>
    </div>
  </footer>

  <!-- ##############################Footer####################################### -->












  </body>
</template>

<script>

</script>
