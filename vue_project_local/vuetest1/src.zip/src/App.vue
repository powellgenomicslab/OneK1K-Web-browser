<template>
  <div id="app">
    <div id="nav">
      <header>
        <!-- #################################logo############################################## -->
        <!-- 	<div class="l-pad">
         --><div class="fixed-width l-pad">
		<span class="logo">
			<h1>OneK1K</h1>
		</span>
      </div>
        <!-- #################################logo############################################## -->

        <!-- #################################Top bar############################################ -->

        <div class="topbar cf" data-id="topbar">
          <!--         <span class="topbar-style l-sidebar l-pad l-content-constrained">
           -->
          <span class="topbar-style">

			<a href="/">Home</a>
			<a href="/eQTL_table">eQTL</a>
			<a href="/association_table">Association</a>
              <a href="/expression">Expression</a>
			<a href="/">Download</a>

		</span>

        </div>

      </header>
    </div>
    <router-view/>
  </div>
</template>





<style>
  @import "http://meyerweb.com/eric/tools/css/reset/reset.css";
  @import "http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.css";
  @import "http://fonts.googleapis.com/css?family=Stoke:300|Roboto:400,300";
  @import "assets/main.css";
  @import "https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css";
  @import "https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.css";
  @import "https://cdn.datatables.net/v/dt/dt-1.10.21/b-1.6.2/b-flash-1.6.2/b-html5-1.6.2/b-print-1.6.2/datatables.min.css"
</style>
